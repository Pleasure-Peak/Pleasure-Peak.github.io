<?php
// Get form data
$name    = $_POST['name'];
$email   = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Compose the email
$to      = "bbalesharif@gmail.com";
$mailSubject = "New contact form submission: $subject";
$body    = "You have a new contact message from:\n\n".
           "Name: $name\n".
           "Email: $email\n\n".
           "Message:\n$message\n";

$headers = "From: $email\r\nReply-To: $email\r\n";

// Send the email
if(mail($to, $mailSubject, $body, $headers)){
    echo "Your message was sent successfully.";
} else {
    echo "Sorry, there was a problem sending your message.";
}
?>
